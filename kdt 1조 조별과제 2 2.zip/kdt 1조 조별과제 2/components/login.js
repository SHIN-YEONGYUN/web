"use strict";

const usersData = [
    {
        id: 'user',
        password: '1234',
    },
    {
        id: "admin",
        password: '1234',
    },
];

const loginId = document.getElementById('LOGIN_ID');
const loginPw = document.getElementById('LOGIN_PW');
const loginBtn = document.getElementById('LOGIN_BTN');

function color() {
    if (loginId.value.length > 3 && loginPw.value.length > 3) {
        loginBtn.disabled = false;
    } else {
        loginBtn.disabled = true;
    }
}

function moveToMain() {
    location.replace("./index.html");
}

loginId.addEventListener('keyup', color);
loginPw.addEventListener('keyup', color);
loginBtn.addEventListener('click', moveToMain);

// function LOGIN_CHK() {
//     let id = document.getElementById("LOGIN_ID");
//     let pw = document.getElementById("LOGIN_PW");

//     if (pw.value != usersData.password) {
//         if (id.value != usersData.id) {
//             alert("아이디와 비밀번호 모두 다시 확인해주세요.");
//             id.focus();
//             return false;
//         }
//     }
//     else if (pw.value != usersData.password) {
//         alert("비밀번호를 다시 확인해주세요.");
//         pw.focus();
//         return false;
//     } else if (id.value != usersData.id) {
//         alert("아이디를 다시 확인해주세요.");
//         id.focus();
//         return false;
//     }
//     else {
//         alert("로그인 완료되었습니다.");
//         form.submit();
//     }
// };