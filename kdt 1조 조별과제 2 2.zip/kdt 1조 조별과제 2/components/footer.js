const info = {
  name: 'KDT 쇼핑',
  address: '가가시 가가구 가가로 111',
  phone: '1111-1111',
  email: 'aaa@kdt.com',
};

const $footer = document.querySelector('footer');

const $name = document.createElement('div');
const $address = document.createElement('div');
const $phone = document.createElement('div');
const $email = document.createElement('div');

$name.innerText = info.name;
$address.innerText = info.address;
$phone.innerText = info.phone;
$email.innerText = info.email;

$footer.append($name, $address, $phone, $email);
