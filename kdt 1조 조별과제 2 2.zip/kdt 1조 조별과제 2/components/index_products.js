const index_products_categories = [
  '상의',
  '하의',
  'Shoes',
  'Cap',
  'Accessories',
];

const categories = {
  top: '상의',
  bottom: '하의',
};

export const products = [
  {
    id: 1,
    title: '남성 캐주얼 슬림핏 티셔츠',
    price: 22300,
    description:
      '슬림핏 스타일, 콘트라스트 래글런 롱슬리브, 3버튼 헨리 플래킷, 가볍고 부드러운 원단으로 통기성과 편안한 착용감을 제공합니다. 라운드넥 솔리드 스티치 셔츠로 내구성과 핏이 우수하여 캐주얼 패션웨어와 열렬한 야구 팬에게 적합합니다. .헨리 스타일의 라운드 네크라인에 쓰리버튼 플래킷이 포함되어 있습니다.',
    category: categories.top,
    image: '../assets/index/상의/1.jpg',
    count: 10,
  },
  {
    id: 2,
    title: '남성 면 자켓',
    price: 169000,
    description:
      '작업, 하이킹, 캠핑, 산악/암벽 등반, 자전거 타기, 여행 또는 기타 야외 활동과 같은 많은 경우에 적합한 봄/가을/겨울용 훌륭한 아우터 재킷. 당신 또는 당신의 가족을 위한 좋은 선물 선택. 이 추수 감사절이나 성탄절에 아버지, 남편 또는 아들에게 따뜻한 마음의 사랑을 전하십시오.',
    category: categories.top,
    image: '../assets/index/상의/2.jpg',
    count: 20,
  },
  {
    id: 3,
    title: '남성 캐주얼 슬림핏 맨투맨',
    price: 59000,
    description:
      '색상은 화면과 실제로 약간 다를 수 있습니다. / 체형은 개인차가 있으므로 자세한 사이즈 정보는 상품설명 하단을 참고하시기 바랍니다.',
    category: categories.top,
    image: '../assets/index/상의/3.jpg',
    count: 15,
  },
  {
    id: 4,
    title: '여성 스노우보드 자켓',
    price: 249000,
    description:
      '참고: 재킷은 미국 표준 크기입니다. 평소 착용할 때 크기를 선택하십시오. 재질: 100% 폴리에스터; 분리형 라이너 원단: 따뜻한 양털. 탈착식 기능성 라이너: 피부 친화적이고 가볍고 따뜻합니다. 스탠드 칼라 라이너 재킷으로 추운 날씨에 따뜻하게 유지하십시오. 지퍼가 달린 주머니: 지퍼가 달린 손 주머니 2개, 가슴에 지퍼가 달린 주머니 2개(카드나 열쇠를 보관하기에 충분함) 및 내부에 숨겨진 주머니 1개. 지퍼가 달린 손 주머니와 숨겨진 주머니는 물건을 안전하게 보관합니다. 인간화 디자인: 편안한 착용감을 위해 바람과 물을 방지하기 위해 조정 가능하고 분리 가능한 후드와 조정 가능한 커프스. 3 in 1 탈착식 디자인으로 더욱 편리하며, 필요에 따라 코트와 이너를 분리하거나 함께 착용할 수 있습니다. 다른 계절에 적합하며 다른 기후에 적응하는 데 도움이됩니다.',
    category: categories.top,
    image: '../assets/index/상의/4.jpg',
    count: 17,
  },
  {
    id: 5,
    title: '여성 인조가죽 자켓',
    price: 147000,
    description:
      '(겉감) 100% 폴리우레탄 (안감) 75% 폴리에스테르 25% 면, 스타일과 편안함을 위한 인조가죽 소재 / 앞포켓 2개, 투포원 후드 데님 스타일 인조가죽 재킷, 버튼 디테일 허리 / 옆면 디테일 스티치, 손세탁만 가능, 표백 금지, 다림질 금지',
    category: categories.top,
    image: '../assets/index/상의/5.jpg',
    count: 12,
  },
  {
    id: 6,
    title: '여성 레인 코트, 파란색',
    price: 330000,
    description:
      '여행이나 평상복을 위한 가벼운 퍼펫---후드가 있는 긴 소매, 조절 가능한 드로스트링 허리 디자인. 버튼과 지퍼 앞 클로저 비옷, 전체 줄무늬 안감 및 비옷에는 2개의 사이드 포켓이 있어 모든 종류의 물건을 담기에 좋은 크기이며 엉덩이를 덮으며 후드는 넉넉하지만 과하지 않습니다. 조절 가능한 드로스트링이 진정한 스타일의 룩을 선사합니다.',
    category: categories.top,
    image: '../assets/index/상의/6.jpg',
    count: 3,
  },
  {
    id: 7,
    title: '여성 티셔츠, 흰색, v낵',
    price: 20000,
    description:
      '95% 레이온 5% 스판덱스, 미국에서 제작, 표백 금지, 가벼운 신축성이 있어 편안함을 주는 원단, 소매와 네크라인에 골지 처리 / 밑단 더블 스티치',
    category: categories.top,
    image: '../assets/index/상의/7.jpg',
    count: 9,
  },
  {
    id: 8,
    title: '여성 티셔츠, 빨간색, v낵',
    price: 19000,
    description:
      '100% 폴리에스터, 기계세탁, 100% 양이온성 폴리에스터 인터로크, 기계세탁 및 사전 수축으로 좋은 핏, 가볍고 넉넉하며 통기성이 뛰어난 수분 흡수 원단으로 습기를 멀리하는 데 도움이 됩니다. 슬림한 핏으로 날렵하고 여성스러운 실루엣과 편안함을 더했습니다.',
    category: categories.top,
    image: '../assets/index/상의/8.jpg',
    count: 13,
  },
  {
    id: 9,
    title: 'STCO 티셔츠/셔츠/팬츠 6900원~ 50종 모음',
    price: 10000,
    description:
      '100% 폴리에스터, 기계세탁 가능, 다림질 가능, 가볍고 넉넉하며 통기성이 뛰어난 수분 흡수 원단으로 습기를 멀리하는 데 도움이 됩니다. 넓은 핏으로 누구나 편하게 입을 수 있습니다.',
    category: categories.top,
    image: '../assets/index/상의/9.jpg',
    count: 13,
  },
  {
    id: 10,
    title: '남성) PRJCT 밀라노 반팔 카라 스웨터_EPD2ER1110',
    price: 9000,
    description:
      '70% 폴리에스터, 30% 면, 세탁기 사용 가능, 다림질 금지, 세련된 색감, 편안한 핏',
    category: categories.top,
    image: '../assets/index/상의/10.jpg',
    count: 2,
  },
  {
    id: 11,
    title: '남성 Fluff Fleece 바지',
    price: 23000,
    description:
      '천연 소재와 재활용 소재로 만든 폭신한 촉감의 따뜻한 플리스 팬츠입니다. 용도: 캐주얼 기능성: 조절 가능한 고무 허리 밴드와 소지품 보관을 위한 핸드 포켓 완벽을 위한 혼방: 테두리는 ZQ 메리노 울과 재활용 소재를 혼방하여 쉽게 해지는 부분에 내구성을 더했습니다.',
    category: categories.bottom,
    image: '../assets/index/하의/11.jpg',
    count: 19,
  },
  {
    id: 12,
    title: 'SL01 섬머 데님 와이드 팬츠 (RAW INDIGO)',
    price: 23000,
    description:
      '코튼소재의 편안함과 더불어 다양한 연출이 가능합니다. 원턱으로 하프, 골반라인 여유가 있는 핏으로 귀여운 연출이 가능한 긴바지입니다.',
    category: categories.bottom,
    image: '../assets/index/하의/12.jpg',
    count: 11,
  },
  {
    id: 13,
    title: '가비진 여성용 와이드 일자 밴드 팬츠',
    price: 13900,
    description:
      '골지패턴으로 편안함은 물론, 촉감마저 좋은 팬츠, 키작녀, 키큰녀 모두 고민하지 마시길 - 숏기장, 롱기장이 존재합니다. 허리에 고무줄이 있어 편안하게 착용할 수 있습니다.',
    category: categories.bottom,
    image: '../assets/index/하의/13.jpg',
    count: 8,
  },
  {
    id: 14,
    title: '가비진 남성용 일자 롱 팬츠',
    price: 15000,
    description:
      '더위를 날릴 새로운 일상을 전해줄 쿨 팬츠, 쾌적한 통기성, 4방향 신축성, 전체 스판으로 착용 시 편안함은 물론 쾌적하게 착용할 수 있는 팬츠입니다.',
    category: categories.bottom,
    image: '../assets/index/하의/14.jpg',
    count: 8,
  },
  {
    id: 15,
    title: '빅사이즈클럽 남성용 JIN 스판 밴딩 면바지',
    price: 21950,
    description:
      '체형에 맞는 디자인: 수년간 고객님들의 의견을 반영했습니다, 합리적인 가격: 유통 과정에서 일어나는 손실을 최소로 했습니다. 세탁기 가능, 드라이 클리닝 금지',
    category: categories.bottom,
    image: '../assets/index/하의/15.jpg',
    count: 7,
  },
  {
    id: 16,
    title: '망고베이비 여성 스판 여름스커트 프릴 미니 스커트',
    price: 18900,
    description:
      '매력있는 바디라인을 연출해 주는 여성스러운 느낌의 하이웨스트 디자인에 언발란스한 밑단 프릴 디테일로 포인트를 준 큐롯입니다. 또한 속바지가 세팅되어 있어 활동성을 높여주고 노출을 방지해 주어 안심하고 착용할 수 있습니다.',
    category: categories.bottom,
    image: '../assets/index/하의/16.jpg',
    count: 7,
  },
  {
    id: 17,
    title: '여성 편하고 예쁜 밴딩 주름 링클 롱 스커트 살랑살랑 데일리로 굿!',
    price: 15900,
    description:
      '키작여 언니들도 OK! 과하지 않은 주름으로 여성스러운 분위기를 풍기는 계속 찾게 되는 편하고 부담 없는 주름 스커트',
    category: categories.bottom,
    image: '../assets/index/하의/17.jpg',
    count: 10,
  },
  {
    id: 18,
    title: '가비진 여성용 슬림핏 A라인 레더 미니 속바지 안감 스커트 치마',
    price: 15070,
    description:
      '베이직한 디테일, 은은한 분위기가 살아나는 컬러, 간절기에 정말 활용도가 좋은 아이템, 원단 촉감까지 정말 좋음',
    category: categories.bottom,
    image: '../assets/index/하의/18.jpg',
    count: 11,
  },
  {
    id: 19,
    title: '남녀공용 빅사이즈 카고조거팬츠 (MDLP513BM)',
    price: 19800,
    description:
      '일자핏 카고조거 디자인으로 핏좋은 트레이닝 팬츠, 부드러운 특양면원단으로 가볍게 착용하기 좋은 트레이닝 팬츠입니다. 조거와 카고포켓 디자인으로 착용 핏이 이쁜 상품이며 일자핏으로 편하게 착용하기 좋은 팬츠입니다.',
    category: categories.bottom,
    image: '../assets/index/하의/19.jpg',
    count: 1,
  },
  {
    id: 20,
    title: '[당일출고] 남녀공용 매일편하게 와이드팬츠 (MDIP121LJ)',
    price: 12800,
    description:
      '매일매일 입고 싶은 잘 빠진 와이드핏 트레이닝 팬츠, 부드럽고 매끈한 원단감으로 피부에 자극적이지 않은 상품입니다. 가볍게 착용하기 좋은 무게입니다.',
    category: categories.bottom,
    image: '../assets/index/하의/20.jpg',
    count: 20,
  },
  {
    id: 21,
    title: 'SlipOn',
    price: 66000,
    description: `체온 조절 기능이 있는 부드러운 초극세 프리미엄 ZQ 메리노 울로 만들었습니다.

    ZQRx 재생 농법으로 생산된 울 소재: Regen Capsule에 사용된 울은 재생 농법으로 생산되어 자연 보존과 기후 변화 대응에 기여합니다. 올버즈 재생 농법에 관해 더 자세히 알아보기.
    용도: 워킹, 데일리 스니커즈

    부드러운 소재: 부드럽고 따뜻한 프리미엄 ZQ 메리노 울이 포근함과 편안함을 제공합니다.

    심플한 디자인: 어떤 스타일에도 어울리는 디자인

    제조국: 대한민국.`,
    category: 'Shoes',
    image: '../assets/index/신발/SlipOn.webp',
    count: 1,
  },
  {
    id: 22,
    title: 'Running Shoes(GR)',
    price: 93000,
    description: `체온 조절 기능이 있는 부드러운 초극세 프리미엄 ZQ 메리노 울로 만들었습니다.

    ZQRx 재생 농법으로 생산된 울 소재: Regen Capsule에 사용된 울은 재생 농법으로 생산되어 자연 보존과 기후 변화 대응에 기여합니다. 올버즈 재생 농법에 관해 더 자세히 알아보기.
    용도: 워킹, 데일리 스니커즈

    부드러운 소재: 부드럽고 따뜻한 프리미엄 ZQ 메리노 울이 포근함과 편안함을 제공합니다.

    심플한 디자인: 어떤 스타일에도 어울리는 디자인

    제조국: 대한민국.`,
    category: 'Shoes',
    image: '../assets/index/신발/RunningShoes(GR).webp',
    count: 18,
  },
  {
    id: 23,
    title: 'Running Shoes(BK)',
    price: 69000,
    description: `체온 조절 기능이 있는 부드러운 초극세 프리미엄 ZQ 메리노 울로 만들었습니다.

      ZQRx 재생 농법으로 생산된 울 소재: Regen Capsule에 사용된 울은 재생 농법으로 생산되어 자연 보존과 기후 변화 대응에 기여합니다. 올버즈 재생 농법에 관해 더 자세히 알아보기.
      용도: 워킹, 데일리 스니커즈

      부드러운 소재: 부드럽고 따뜻한 프리미엄 ZQ 메리노 울이 포근함과 편안함을 제공합니다.

    심플한 디자인: 어떤 스타일에도 어울리는 디자인

    제조국: 대한민국.`,
    category: 'Shoes',
    image: '../assets/index/신발/RunningShoes(BK).webp',
    count: 11,
  },
  {
    id: 24,
    title: 'Running Shoes(WH)',
    price: 76000,
    description: `체온 조절 기능이 있는 부드러운 초극세 프리미엄 ZQ 메리노 울로 만들었습니다.

  ZQRx 재생 농법으로 생산된 울 소재: Regen Capsule에 사용된 울은 재생 농법으로 생산되어 자연 보존과 기후 변화 대응에 기여합니다. 올버즈 재생 농법에 관해 더 자세히 알아보기.
  용도: 워킹, 데일리 스니커즈

  부드러운 소재: 부드럽고 따뜻한 프리미엄 ZQ 메리노 울이 포근함과 편안함을 제공합니다.

  심플한 디자인: 어떤 스타일에도 어울리는 디자인

  제조국: 대한민국.`,
    category: 'Shoes',
    image: '../assets/index/신발/RunningShoes(WH).webp',
    count: 14,
  },
  {
    id: 25,
    title: 'Low Sneakers',
    price: 76000,
    description: `하루 종일 편안한 데일리 스타일. 당신이 기다려온 프리미엄 ZQ 메리노 울로 만든 클래식 로우탑 스니커즈

용도: 워킹, 추운 날씨, 데일리

부드러운 소재: 따뜻하고 포근한 프리미엄 ZQ 메리노 울은 업그레이드된 편안함을 제공합니다

심플한 디자인: 데일리 클래식 디자인, 여행에 적합한 디자인

제조국: 대한민국. `,
    category: 'Shoes',
    image: '../assets/index/신발/LowSneakers.webp',
    count: 5,
  },
  {
    id: 26,
    title: 'Black Ball Cap',
    price: 16000,
    description: `가장 베이직한 스타일로 어떤 패션에나 잘 어울리는 모자입니다.
      적당한 깊이감과 길게 뻗은 창, 자연스러운 커브로 최적의 스타일감을 뽐낼 수 있습니다.`,
    category: 'Cap',
    image: '../assets/index/모자/BlackBallCap.jpg',
    count: 15,
  },
  {
    id: 27,
    title: 'Blue Ball Cap',
    price: 15000,
    description: `가장 베이직한 스타일로 어떤 패션에나 잘 어울리는 모자입니다.
      적당한 깊이감과 길게 뻗은 창, 자연스러운 커브로 최적의 스타일감을 뽐낼 수 있습니다.`,
    category: 'Cap',
    image: '../assets/index/모자/BlueBallCap.jpg',
    count: 9,
  },
  {
    id: 28,
    title: 'Pink Ball Cap',
    price: 13000,
    description: `가장 베이직한 스타일로 어떤 패션에나 잘 어울리는 모자입니다.
      적당한 깊이감과 길게 뻗은 창, 자연스러운 커브로 최적의 스타일감을 뽐낼 수 있습니다.`,
    category: 'Cap',
    image: '../assets/index/모자/PinkBallCap.jpg',
    count: 16,
  },
  {
    id: 29,
    title: 'Navy Beanie',
    price: 10000,
    description: `가장 베이직한 디자인의 비니
    두껍지않아 4계절용으로 사용
    신축성 좋은 아크릴 소재
    롱한 기장감으로 기호에 맞게 접어 착용
    두상이 커도 잘맞는 남녀 공용 free 사이즈`,
    category: 'Cap',
    image: '../assets/index/모자/NavyBeanie.jpg',
    count: 6,
  },
  {
    id: 30,
    title: 'Beige Beanie',
    price: 11000,
    description: `가장 베이직한 디자인의 비니
    두껍지않아 4계절용으로 사용
    신축성 좋은 아크릴 소재
    롱한 기장감으로 기호에 맞게 접어 착용
    두상이 커도 잘맞는 남녀 공용 free 사이즈`,
    category: 'Cap',
    image: '../assets/index/모자/BeigeBeanie.jpg',
    count: 4,
  },
  {
    id: 31,
    title: 'Dragon Bracelet',
    price: 43000,
    description:
      "From our Legends Collection, the Naga was inspired by the mythical water dragon that protects the ocean's pearl. Wear facing inward to be bestowed with love and abundance, or outward for protection.",
    category: 'Accessories',
    image: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg',
    count: 2,
  },
  {
    id: 32,
    title: 'Silver Ring',
    price: 63000,
    description:
      'Satisfaction Guaranteed. Return or exchange any order within 30 days.Designed and sold by Hafeez Center in the United States. Satisfaction Guaranteed. Return or exchange any order within 30 days.',
    category: 'Accessories',
    image: 'https://fakestoreapi.com/img/61sbMiUnoGL._AC_UL640_QL65_ML3_.jpg',
    count: 3,
  },
  {
    id: 33,
    title: 'Diamond Ring',
    price: 120000,
    description:
      "Classic Created Wedding Engagement Solitaire Diamond Promise Ring for Her. Gifts to spoil your love more for Engagement, Wedding, Anniversary, Valentine's Day...",
    category: 'Accessories',
    image: 'https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg',
    count: 20,
  },
  {
    id: 34,
    title: 'Gold Ring',
    price: 73000,
    description:
      'Rose Gold Plated Double Flared Tunnel Plug Earrings. Made of 316L Stainless Steel',
    category: 'Accessories',
    image: 'https://fakestoreapi.com/img/51UDEzMJVpL._AC_UL640_QL65_ML3_.jpg',
    count: 9,
  },
];

const productsSorted = products.sort((a, b) => b.count - a.count);

const $sectionHomeProducts = document.querySelector('.index__products');

const $categories = index_products_categories.map((category) => {
  const $category = document.createElement('article');
  const $categoryTitle = document.createElement('div');
  const $products = document.createElement('div');
  $category.classList.add('category');
  $categoryTitle.classList.add('category-title');
  $products.classList.add('products');
  $categoryTitle.innerText = category;
  $category.append($categoryTitle, $products);
  return $category;
});

const categoryCount = {};
index_products_categories.forEach((category) => {
  categoryCount[category] = 0;
});

productsSorted.forEach((productDatum) => {
  if (categoryCount[productDatum.category] > 3) {
    return;
  }

  categoryCount[productDatum.category]++;

  const $theCategory = $categories.find(
    ($category) => $category.children[0].innerText == productDatum.category
  );

  const $product = document.createElement('div');
  const $rank = document.createElement('div');
  const $link = document.createElement('a');
  const $imageContainer = document.createElement('div');
  const $image = document.createElement('img');
  const $title = document.createElement('div');
  const $price = document.createElement('div');

  $product.classList.add('product');
  $rank.classList.add('rank');
  $imageContainer.classList.add('image');
  $title.classList.add('product-title');
  $price.classList.add('price');

  $rank.innerText = categoryCount[productDatum.category];
  switch (categoryCount[productDatum.category]) {
    case 1:
      $rank.style.backgroundColor = 'gold';
      break;
    case 2:
      $rank.style.backgroundColor = 'silver';
      break;
    case 3:
      $rank.style.backgroundColor = 'brown';
      break;
    default:
      $rank.style.backgroundColor = 'white';
      break;
  }

  const categoryFolder = {
    상의: 'Tproducts',
    하의: 'Bproducts',
    Shoes: 'Sproducts',
    Cap: 'Cproducts',
    Accessories: 'Aproducts',
  };

  $link.href = `/${categoryFolder[productDatum.category]}/${
    productDatum.id
  }.html`;
  $image.src = productDatum.image;
  $title.innerText = productDatum.title;
  $price.innerText = productDatum.price.toLocaleString() + '원';

  $imageContainer.append($image);
  $link.append($imageContainer, $title, $price);
  $product.append($rank, $link);
  $theCategory.children[1].append($product);
});

$categories.forEach(($category) => {
  $sectionHomeProducts.append($category);
});
