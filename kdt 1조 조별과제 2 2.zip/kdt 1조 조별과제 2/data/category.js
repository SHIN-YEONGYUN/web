const category = ['의류', '장신구', '전자'];
