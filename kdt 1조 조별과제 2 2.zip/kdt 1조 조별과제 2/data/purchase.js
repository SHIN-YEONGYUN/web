const personAndProduct = [
  {
    person: 1,
    product: 2,
  },
  {
    person: 1,
    product: 8,
  },
  {
    person: 1,
    product: 16,
  },
  {
    person: 2,
    product: 1,
  },
  {
    person: 2,
    product: 12,
  },
  {
    person: 2,
    product: 7,
  },
  {
    person: 3,
    product: 17,
  },
  {
    person: 3,
    product: 1,
  },
  {
    person: 3,
    product: 9,
  },
  {
    person: 4,
    product: 19,
  },
  {
    person: 4,
    product: 20,
  },
  {
    person: 4,
    product: 6,
  },
  {
    person: 5,
    product: 1,
  },
  {
    person: 5,
    product: 3,
  },
  {
    person: 5,
    product: 5,
  },
];
