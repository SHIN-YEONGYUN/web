// -------------------------------------------
// 데이터
// -------------------------------------------

const data = [
  {
    title: '멋진 상의!',
    description: '이제부터 멋과 편안함을 누려보세요!',
    image: '/assets/index/tops.jpg',
    link: '/top.html',
  }, 
  {
    title: '물빠진 청바지!',
    description: '이제 막 도착한 신상 청바지를 구경해 보세요!',
    image: '/assets/index/bottoms.jpg',
    link: '/bottom.html',
  },
  {
    title: '화려한 색상의 신발들!',
    description: '당신 패션의 마침표로 이 신발을 선물합니다!',
    image: '/assets/index/shoes.jpg',
    link: '/shoe.html',
  },
  {
    title: '편안하면서도 세련된 모자들!',
    description: '이 모자를 착용하면 당신의 멋짐이 드러날 것입니다!',
    image: '/assets/index/caps.jpg',
    link: '/cap.html',
  },
  {
    title: '아름다운 반지!',
    description: '당신을 빛낼 아름다운 반지가 준비되어 있습니다!',
    image: '/assets/index/accessory.jpg',
    link: '/accessories.html',
  },
];

// -------------------------------------------
// 요소 생성
// -------------------------------------------

const $section = document.querySelector('.index__slide');

// 겉 요소들: 생성
const $container = document.createElement('div');
const $btnLeft = document.createElement('button');
const $btnRight = document.createElement('button');
const $btnLeftImage = document.createElement('img');
const $btnRightImage = document.createElement('img');

// 겉 요소들: 스타일을 위해 클래스 추가
$container.classList.add('slide-container');
$btnLeft.classList.add('btn', 'btn-left');
$btnRight.classList.add('btn', 'btn-right');

// 겉 요소들: 내용 추가
$btnLeftImage.src = '/assets/index/btn-left.svg';
$btnRightImage.src = '/assets/index/btn-right.svg';

// 겉 요소들: 결합
$btnLeft.append($btnLeftImage);
$btnRight.append($btnRightImage);

// 내부 요소들: 생성
function makeSlide(title, description, image, link) {
  const $slide = document.createElement('div');
  const $content = document.createElement('div');
  const $title = document.createElement('div');
  const $description = document.createElement('div');
  const $linkWrapper = document.createElement('div');
  const $link = document.createElement('a');
  const $image = document.createElement('img');

  // 스타일을 위해 클래스 추가
  $slide.classList.add('slide');
  $content.classList.add('content');
  $title.classList.add('title');
  $description.classList.add('description');
  $linkWrapper.classList.add('link');

  // 내용 넣기
  $title.innerText = title;
  $description.innerText = description;
  $image.src = image;
  $link.innerText = '바로가기';
  $link.href = link;

  // 결합하기
  $linkWrapper.append($link);
  $content.append($title, $description, $linkWrapper);
  $slide.append($content, $image);

  return $slide;
}

// 최종 결합하기
data.forEach(({ title, description, image, link }) => {
  const $slide = makeSlide(title, description, image, link);
  $container.append($slide);
});
$section.append($container, $btnLeft, $btnRight);

// -------------------------------------------
// 기능 추가
// -------------------------------------------
let positionIndex = 0;
const countSlide = 5;

$btnLeft.onclick = (e) => {
  positionIndex++;
  if (positionIndex > 0) {
    positionIndex = -countSlide + 1;
  }
  const position = (positionIndex * 100) / countSlide;
  $container.style.transform = `translateX(${position}%)`;
};

$btnRight.onclick = (e) => {
  positionIndex--;
  if (positionIndex < -countSlide + 1) {
    positionIndex = 0;
  }
  const position = (positionIndex * 100) / countSlide;
  $container.style.transform = `translateX(${position}%)`;
};

addEventListener('resize', () => {
  for (const $slide of $container.children) {
    $slide.style.width = '100%';
  }
});
