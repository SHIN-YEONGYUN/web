"use strict";

const usersData = [
    {
        id: 'user',
        password: '1234',
    },
    {
        id: "admin",
        password: '1234',
    },
];

const mypagenumber = document.getElementById('usernumber');
const mypageid = document.getElementById('userid');
const mypagename = document.getElementById('username');
const mypagepw = document.getElementById('userpw');
const mypagephone = document.getElementById('userphone');
const mypageemail = document.getElementById('useremail');
const mypagebtn = document.getElementById('userbtn');

function color() {
    if (mypagename.value.length > 2 && mypagepw.value.length > 3 && mypagephone.value.length > 11 && mypageemail.value.length > 9) {
        mypagebtn.disabled = false;
    } else {
        mypagebtn.disabled = true;
    }
}

// mypagename.addEventListener('keyup', color);
// mypagepw.addEventListener('keyup', color);
// mypagephone.addEventListener('keyup', color);
// mypageemail.addEventListener('keyup', color);

function mypage_CHK() {
    let name = document.getElementById("username");
    let pw = document.getElementById("userpw");
    let phone = document.getElementById("userphone");
    let email = document.getElementById("useremail");

    if (pw.value == "") {
        alert("비밀번호를 확인해주세요.");
        pw.focus();
    }
    else if (name.value == "") {
        alert("이름을 확인해주세요.");
        name.focus();
    } else if (phone.value == "") {
        alert("전화번호를 확인해주세요.");
        phone.focus();
    } else if (email.value == "") {
        alert("이메일을 확인해주세요.");
        email.focus();
    }
    else {
        alert("회원정보 수정 완료되었습니다.");
        form.submit();
    }
};