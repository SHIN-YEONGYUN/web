const links = {
  home: '/index.html',
  category1: '/top.html',
  category2: '/bottom.html',
  category3: '/cap.html',
  category4: '/shoes.html',
  category5: '/accessories.html',
  buylist: '/buylist.html',
  myPage: '/MyPage.html',
  board: '/noticeList.html',
  sign: '/index.html',
  cart: '/cart.html',
};

const $header = document.querySelector('header');

// 요소 생성
const $narrowCategoryButton = document.createElement('button');
const $narrowCategoryContainer = document.createElement('div');
const $narrowCategory1 = document.createElement('div');
const $narrowCategory2 = document.createElement('div');
const $narrowCategory3 = document.createElement('div');
const $narrowCategory4 = document.createElement('div');
const $narrowCategory5 = document.createElement('div');
const $logo = document.createElement('div');
const $category1 = document.createElement('div');
const $category2 = document.createElement('div');
const $category3 = document.createElement('div');
const $category4 = document.createElement('div');
const $category5 = document.createElement('div');
const $space = document.createElement('div');
const $buylist = document.createElement('div');
const $myPage = document.createElement('div');
const $board = document.createElement('div');
const $sign = document.createElement('div');
const $cart = document.createElement('div');

// 링크 생성
const $narrowCategory1Link = document.createElement('a');
$narrowCategory1Link.href = links.category1;
const $narrowCategory2Link = document.createElement('a');
$narrowCategory2Link.href = links.category2;
const $narrowCategory3Link = document.createElement('a');
$narrowCategory3Link.href = links.category3;
const $narrowCategory4Link = document.createElement('a');
$narrowCategory4Link.href = links.category4;
const $narrowCategory5Link = document.createElement('a');
$narrowCategory5Link.href = links.category5;
const $logoLink = document.createElement('a');
$logoLink.href = links.home;
const $category1Link = document.createElement('a');
$category1Link.href = links.category1;
const $category2Link = document.createElement('a');
$category2Link.href = links.category2;
const $category3Link = document.createElement('a');
$category3Link.href = links.category3;
const $category4Link = document.createElement('a');
$category4Link.href = links.category4;
const $category5Link = document.createElement('a');
$category5Link.href = links.category5;
const $buylistLink = document.createElement('a');
$buylistLink.href = links.buylist;
const $myPageLink = document.createElement('a');
$myPageLink.href = links.myPage;
const $boardLink = document.createElement('a');
$boardLink.href = links.board;
const $signLink = document.createElement('a');
$signLink.href = links.sign;
const $cartLink = document.createElement('a');
$cartLink.href = links.cart;
$logo.append($logoLink);
$narrowCategory1.append($narrowCategory1Link);
$narrowCategory2.append($narrowCategory2Link);
$narrowCategory3.append($narrowCategory3Link);
$narrowCategory4.append($narrowCategory4Link);
$narrowCategory5.append($narrowCategory5Link);
$category1.append($category1Link);
$category2.append($category2Link);
$category3.append($category3Link);
$category4.append($category4Link);
$category5.append($category5Link);
$buylist.append($buylistLink);
$myPage.append($myPageLink);
$board.append($boardLink);
$sign.append($signLink);
$cart.append($cartLink);

// 스타일을 위해 클래스 지정
const classNames = {
  logo: 'logo',
  category: 'category',
  space: 'space',
  iconRight: 'icon-right',
  narrowCategoryButton: 'narrow-category-button',
  narrowCategory: 'narrow-category-container',
};
$narrowCategoryButton.classList.add(classNames.narrowCategoryButton);
$narrowCategoryContainer.classList.add(classNames.narrowCategory);
$logo.classList.add(classNames.logo);
$category1.classList.add(classNames.category);
$category2.classList.add(classNames.category);
$category3.classList.add(classNames.category);
$category4.classList.add(classNames.category);
$category5.classList.add(classNames.category);
$space.classList.add(classNames.space);
$buylist.classList.add(classNames.iconRight);
$myPage.classList.add(classNames.iconRight);
$board.classList.add(classNames.iconRight);
$sign.classList.add(classNames.iconRight);
$cart.classList.add(classNames.iconRight);

// 내용 넣기
const $narrowCategoryButtonIcon = document.createElement('img');
$narrowCategoryButtonIcon.src = '/assets/index/menu.svg';
$narrowCategoryButton.append($narrowCategoryButtonIcon);
$logoLink.innerText = '🅺🅳🆃';
$narrowCategory1Link.innerText = '상의';
$narrowCategory2Link.innerText = '하의';
$narrowCategory3Link.innerText = 'Cap';
$narrowCategory4Link.innerText = 'Shoes';
$narrowCategory5Link.innerText = 'Accessories';
$category1Link.innerText = '상의';
$category2Link.innerText = '하의';
$category3Link.innerText = '모자';
$category4Link.innerText = '신발';
$category5Link.innerText = 'Acc';
const $buylistIcon = document.createElement('img');
$buylistIcon.src = '/assets/index/buy.png';
$buylistLink.append($buylistIcon);
const $myPageIcon = document.createElement('img');
$myPageIcon.src = '/assets/index/m.png';
$myPageLink.append($myPageIcon);
const $boardIcon = document.createElement('img');
$boardIcon.src = '/assets/index/board.svg';
$boardLink.append($boardIcon);
const $signIcon = document.createElement('img');
$signIcon.src = '/assets/index/logout.png';
$signLink.append($signIcon);
const $cartIcon = document.createElement('img');
$cartIcon.src = '/assets/index/cart.svg';
$cartLink.append($cartIcon);

// 기능
$narrowCategoryButton.onclick = () => {
  $narrowCategoryContainer.classList.toggle('show');
};

// 합치기
$narrowCategoryContainer.append(
  $narrowCategory1,
  $narrowCategory2,
  $narrowCategory3,
  $narrowCategory4,
  $narrowCategory5
);
$header.append(
  $narrowCategoryButton,
  $narrowCategoryContainer,
  $logo,
  $category1,
  $category2,
  $category3,
  $category4,
  $category5,
  $space,
  $buylist,
  $myPage,
  $board,
  $sign,
  $cart
);
